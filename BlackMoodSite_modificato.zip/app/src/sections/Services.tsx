import { useEffect, useRef, useState } from 'react';
import {
  Settings,
  Mic,
  Wand2,
  AudioLines,
  Guitar,
  ListMusic,
  HeadphonesIcon,
  Radio,
} from 'lucide-react';

const services = [
  {
    icon: Settings,
    title: 'Servizi Custom',
    description: 'Soluzioni su misura per esigenze specifiche e progetti particolari.',
  },
  {
    icon: Mic,
    title: 'Registrazioni in Studio',
    description: 'Sessioni di registrazione curate in un ambiente professionale.',
  },
  {
    icon: Wand2,
    title: 'Produzione & Arrangiamento',
    description: 'Supporto creativo e tecnico nello sviluppo dei brani.',
  },
  {
    icon: AudioLines,
    title: 'Mix & Master',
    description: 'Finalizzazione audio mirata e coerente con il progetto.',
  },
  {
    icon: Guitar,
    title: 'IR per Chitarre e Bassi',
    description: 'Impulse response personalizzati per chitarre e bassi.',
  },
  {
    icon: ListMusic,
    title: 'Sequenze per Live',
    description: 'Sequenze e click track per performance dal vivo.',
  },
  {
    icon: HeadphonesIcon,
    title: 'Consulenza Tecnica',
    description: 'Ascolto guidato e confronto tecnico sui progetti.',
  },
  {
    icon: Radio,
    title: 'Service Live',
    description: 'Supporto audio tecnico per eventi e concerti.',
  },
];

export default function Services() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="services"
      ref={sectionRef}
      className="relative min-h-screen overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://i.postimg.cc/y6DzLCHh/26-B-Flip.jpg"
          alt="Servizi"
          className="w-full h-full object-cover"
        />
        {/* Vignette */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(60% 40% at 50% 20%, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.6) 72%)',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-end lg:items-center">
        {/* Panel */}
        <div
          className={`w-full lg:w-[min(33.333%,480px)] glass-panel flex items-center transition-all duration-1000 ${
            isVisible
              ? 'opacity-100 translate-y-0 lg:translate-x-0'
              : 'opacity-0 translate-y-10 lg:-translate-x-20'
          }`}
        >
          <div className="p-5 md:p-6 lg:p-8 w-full">
            {/* Photo (visible on smartphone too) */}
            <div
              className={`lg:hidden mb-4 rounded-xl overflow-hidden border border-white/10 transition-all duration-700 delay-150 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-4'
              }`}
            >
              <img
                src="https://i.postimg.cc/y6DzLCHh/26-B-Flip.jpg"
                alt="Servizi"
                className="w-full h-44 object-cover"
                loading="lazy"
              />
            </div>

            {/* Title */}
            <h2
              className={`text-2xl md:text-3xl lg:text-4xl font-medium text-white mb-5 md:mb-6 transition-all duration-700 delay-200 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-6'
              }`}
            >
              Servizi
            </h2>

            {/* Services List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {services.map((service, index) => (
                <div
                  key={service.title}
                  className={`group flex items-start gap-2.5 p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 hover:border-rose-500/30 transition-all duration-500 ${
                    isVisible
                      ? 'opacity-100 translate-y-0'
                      : 'opacity-0 translate-y-6'
                  }`}
                  style={{ transitionDelay: `${300 + index * 60}ms` }}
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-rose-500/20 flex items-center justify-center group-hover:bg-rose-500/30 transition-colors duration-300">
                    <service.icon className="w-4 h-4 text-rose-400 group-hover:scale-110 transition-transform duration-300" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-semibold text-white mb-0.5 group-hover:text-rose-300 transition-colors duration-300">
                      {service.title}
                    </h3>
                    <p className="text-[10px] text-white/60 leading-tight">
                      {service.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTA removed (Richiedi preventivo) */}
          </div>
        </div>
      </div>
    </section>
  );
}
