import { useEffect, useRef, useState, useCallback } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const rooms = [
  {
    id: 'studio-i',
    title: 'STUDIO I',
    image: 'https://i.postimg.cc/pr70CnRX/IMG-6688.avif',
    description: 'Sala mix & mastering',
  },
  {
    id: 'studio-m',
    title: 'STUDIO M',
    image: 'https://i.postimg.cc/gc6XZ5nV/Blackmood-59.jpg',
    description: 'Regia per produzione e overdub',
  },
  {
    id: 'studio-r',
    title: 'STUDIO R',
    image: 'https://i.postimg.cc/YSWmLGy7/16.jpg',
    description: 'Live room per riprese e prove',
  },
];

export default function Rooms() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goToSlide = useCallback(
    (index: number) => {
      if (isTransitioning) return;
      setIsTransitioning(true);
      setCurrentIndex(index);
      setTimeout(() => setIsTransitioning(false), 600);
    },
    [isTransitioning]
  );

  const nextSlide = useCallback(() => {
    goToSlide((currentIndex + 1) % rooms.length);
  }, [currentIndex, goToSlide]);

  const prevSlide = useCallback(() => {
    goToSlide((currentIndex - 1 + rooms.length) % rooms.length);
  }, [currentIndex, goToSlide]);

  // Auto-play
  useEffect(() => {
    if (isVisible) {
      intervalRef.current = setInterval(nextSlide, 5200);
    }
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isVisible, nextSlide]);

  // Reset timer on manual navigation
  const handleManualNav = (action: () => void) => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    action();
    intervalRef.current = setInterval(nextSlide, 5200);
  };

  // Intersection Observer
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const currentRoom = rooms[currentIndex];

  return (
    <section
      id="rooms"
      ref={sectionRef}
      className="relative h-screen min-h-[600px] overflow-hidden bg-black"
    >
      {/* Slides */}
      <div className="absolute inset-0">
        {rooms.map((room, index) => (
          <div
            key={room.id}
            className={`absolute inset-0 transition-all duration-700 ease-in-out ${
              index === currentIndex
                ? 'opacity-100 scale-100'
                : 'opacity-0 scale-105'
            }`}
          >
            <img
              src={room.image}
              alt={room.title}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
      </div>

      {/* Big Label */}
      <div
        className={`absolute inset-0 flex items-center justify-center pointer-events-none transition-all duration-700 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="text-center">
          <h2
            key={currentRoom.title}
            className="text-[15vw] md:text-[12vw] lg:text-[10vw] font-bold text-white/40 tracking-tight leading-none animate-fade-in"
          >
            {currentRoom.title.split(' ')[0]}
            <span className="block text-rose-500/60">
              {currentRoom.title.split(' ')[1]}
            </span>
          </h2>
        </div>
      </div>

      {/* Caption */}
      <div
        className={`absolute bottom-24 left-6 md:left-10 transition-all duration-700 delay-300 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
        }`}
      >
        <p className="text-sm md:text-base text-white/80 uppercase tracking-widest">
          {currentRoom.title}
        </p>
        <p className="text-xs md:text-sm text-white/50 mt-1">
          {currentRoom.description}
        </p>
      </div>

      {/* Controls */}
      <div
        className={`absolute bottom-6 right-6 md:bottom-10 md:right-10 flex items-center gap-4 transition-all duration-700 delay-500 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
        }`}
      >
        {/* Prev/Next Buttons */}
        <button
          onClick={() => handleManualNav(prevSlide)}
          className="w-12 h-12 rounded-xl bg-black/50 border border-white/20 text-white hover:bg-black/70 hover:border-white/40 transition-all duration-300 flex items-center justify-center"
          aria-label="Slide precedente"
        >
          <ChevronLeft size={24} />
        </button>

        {/* Dots */}
        <div className="flex gap-2">
          {rooms.map((_, index) => (
            <button
              key={index}
              onClick={() => handleManualNav(() => goToSlide(index))}
              className={`w-3 h-3 rounded-full border border-white transition-all duration-300 ${
                index === currentIndex
                  ? 'bg-white scale-110'
                  : 'bg-transparent opacity-60 hover:opacity-100'
              }`}
              aria-label={`Vai a slide ${index + 1}`}
            />
          ))}
        </div>

        <button
          onClick={() => handleManualNav(nextSlide)}
          className="w-12 h-12 rounded-xl bg-black/50 border border-white/20 text-white hover:bg-black/70 hover:border-white/40 transition-all duration-300 flex items-center justify-center"
          aria-label="Slide successiva"
        >
          <ChevronRight size={24} />
        </button>
      </div>

      {/* Room indicators */}
      <div
        className={`absolute top-1/2 right-6 md:right-10 -translate-y-1/2 flex flex-col gap-3 transition-all duration-700 delay-700 ${
          isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-6'
        }`}
      >
        {rooms.map((room, index) => (
          <button
            key={room.id}
            onClick={() => handleManualNav(() => goToSlide(index))}
            className={`text-xs uppercase tracking-widest transition-all duration-300 text-left ${
              index === currentIndex
                ? 'text-white font-semibold'
                : 'text-white/40 hover:text-white/70'
            }`}
          >
            {room.title}
          </button>
        ))}
      </div>
    </section>
  );
}
