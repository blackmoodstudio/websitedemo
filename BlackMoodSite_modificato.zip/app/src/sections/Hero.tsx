import { useEffect, useRef, useState } from 'react';
import { Apple, Play } from 'lucide-react';

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section
      id="home"
      ref={sectionRef}
      className="relative h-screen min-h-[600px] overflow-hidden"
    >
      {/* Background Image with Ken Burns effect */}
      <div className="absolute inset-0">
        <img
          src="https://i.postimg.cc/1t1shRHb/24.jpg"
          alt="Black Mood Studio"
          className={`w-full h-full object-cover transition-transform duration-[20000ms] ease-linear ${
            isVisible ? 'scale-110' : 'scale-100'
          }`}
        />
        {/* Vignette overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/70" />
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(60% 40% at 50% 20%, rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.55) 70%)',
          }}
        />
      </div>

      {/* Animated gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-rose-900/20 via-transparent to-black/40 animate-gradient" />

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-end pb-8 md:pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto w-full">
          {/* App Banner */}
          <div
            className={`transition-all duration-1000 delay-500 ${
              isVisible
                ? 'opacity-100 translate-y-0'
                : 'opacity-0 translate-y-10'
            }`}
          >
            <div className="glass-panel rounded-2xl md:rounded-3xl p-4 md:p-5 flex items-center gap-4 max-w-xl backdrop-blur-xl border border-white/15 shadow-2xl">
              {/* App Icon */}
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-xl md:rounded-2xl overflow-hidden border border-white/20 bg-black/30 flex-shrink-0 animate-pulse-glow">
                <img
                  src="https://i.postimg.cc/522nFVvV/Logo_app.png"
                  alt="Black Mood Studio App"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Text */}
              <div className="flex-1 min-w-0">
                <p className="text-xs md:text-sm font-semibold text-white/80 uppercase tracking-widest">
                  Scarica l'app
                </p>
                <p className="text-sm md:text-base font-medium text-white truncate">
                  Black Mood Studio
                </p>
              </div>

              {/* Store Buttons */}
              <div className="flex gap-2 md:gap-3">
                <a
                  href="#"
                  className="btn-shine flex items-center justify-center w-10 h-10 md:w-auto md:h-10 md:px-4 rounded-xl bg-black/40 border border-white/20 text-white hover:bg-black/60 hover:border-white/30 transition-all duration-300"
                  aria-label="App Store"
                >
                  <Apple size={18} />
                  <span className="hidden md:inline ml-2 text-xs font-semibold uppercase tracking-wider">
                    App Store
                  </span>
                </a>
                <a
                  href="#"
                  className="btn-shine flex items-center justify-center w-10 h-10 md:w-auto md:h-10 md:px-4 rounded-xl bg-black/40 border border-white/20 text-white hover:bg-black/60 hover:border-white/30 transition-all duration-300"
                  aria-label="Google Play"
                >
                  <Play size={18} />
                  <span className="hidden md:inline ml-2 text-xs font-semibold uppercase tracking-wider">
                    Play Store
                  </span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        className={`absolute bottom-8 left-1/2 -translate-x-1/2 transition-all duration-1000 delay-1000 ${
          isVisible ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs text-white/50 uppercase tracking-widest">
            Scopri di più
          </span>
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-white/60 rounded-full animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}
