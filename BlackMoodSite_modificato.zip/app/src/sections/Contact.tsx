import { useEffect, useRef, useState } from 'react';
import { Mail, Phone, MapPin, Instagram, Facebook } from 'lucide-react';

const socialLinks = [
  {
    icon: Instagram,
    name: 'Instagram',
    handle: '@blackmoodstudio',
    href: 'https://www.instagram.com/blackmoodstudio?igsh=OGIyOXl4OGdtcXJ2&utm_source=qr',
    gradient: 'from-pink-500 via-yellow-500 to-purple-500',
  },
  {
    icon: Facebook,
    name: 'Facebook',
    handle: 'Black Mood Studio',
    href: 'https://www.facebook.com/share/17k13UUqeF/?mibextid=wwXIfr',
    gradient: 'from-blue-600 to-blue-400',
  },
];

export default function Contact() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <footer
      id="contact"
      ref={sectionRef}
      className="relative bg-neutral-100 text-neutral-900"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        {/* Content */}
        <div
          className={`transition-all duration-700 ${
            isVisible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-neutral-900 mb-3 text-center">
            Contatti
          </h2>
          <p className="text-neutral-600 mb-8 md:mb-10 text-center text-sm md:text-base">
            Prenotazioni, preventivi, collaborazioni
          </p>

          {/* Contact Info Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 mb-8 md:mb-10">
            {/* Email */}
            <a
              href="mailto:info@blackmoodstudio.com"
              className="flex items-center gap-3 p-3 md:p-4 rounded-xl bg-white border border-neutral-200 hover:border-rose-300 hover:shadow-md transition-all duration-300 group"
            >
              <div className="w-9 h-9 md:w-10 md:h-10 rounded-lg bg-rose-100 flex items-center justify-center group-hover:bg-rose-200 transition-colors duration-300 flex-shrink-0">
                <Mail className="w-4 h-4 md:w-5 md:h-5 text-rose-600" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] md:text-xs text-neutral-500 uppercase tracking-wider">
                  Email
                </p>
                <p className="text-neutral-900 font-medium text-sm truncate">
                  info@blackmoodstudio.com
                </p>
              </div>
            </a>

            {/* Phone/WhatsApp */}
            <a
              href="https://wa.me/393484871143"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 md:p-4 rounded-xl bg-white border border-neutral-200 hover:border-green-300 hover:shadow-md transition-all duration-300 group"
            >
              <div className="w-9 h-9 md:w-10 md:h-10 rounded-lg bg-green-100 flex items-center justify-center group-hover:bg-green-200 transition-colors duration-300 flex-shrink-0">
                <Phone className="w-4 h-4 md:w-5 md:h-5 text-green-600" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] md:text-xs text-neutral-500 uppercase tracking-wider">
                  WhatsApp
                </p>
                <p className="text-neutral-900 font-medium text-sm">
                  348 4871143
                </p>
              </div>
            </a>

            {/* Address */}
            <div className="flex items-center gap-3 p-3 md:p-4 rounded-xl bg-white border border-neutral-200">
              <div className="w-9 h-9 md:w-10 md:h-10 rounded-lg bg-neutral-100 flex items-center justify-center flex-shrink-0">
                <MapPin className="w-4 h-4 md:w-5 md:h-5 text-neutral-600" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] md:text-xs text-neutral-500 uppercase tracking-wider">
                  Indirizzo
                </p>
                <p className="text-neutral-900 font-medium text-sm truncate">
                  Via Nino Oxilia 4, Novara
                </p>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="text-center">
            <p className="text-[10px] md:text-xs text-neutral-500 uppercase tracking-wider mb-3 md:mb-4">
              Social
            </p>
            <div className="flex justify-center gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-2 md:gap-3 px-4 py-2.5 md:px-5 md:py-3 rounded-xl bg-gradient-to-r ${social.gradient} text-white hover:shadow-lg hover:scale-105 transition-all duration-300`}
                >
                  <social.icon className="w-4 h-4 md:w-5 md:h-5" />
                  <div>
                    <p className="text-[10px] opacity-90 hidden sm:block">{social.name}</p>
                    <p className="text-xs md:text-sm font-medium">{social.handle}</p>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div
          className={`mt-10 md:mt-12 pt-6 md:pt-8 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-3 transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <p className="text-xs md:text-sm text-neutral-500 text-center sm:text-left">
            © {new Date().getFullYear()} Black Mood Studio — Recording • Mixing •
            Mastering
          </p>
          <a
            href="https://sites.google.com/view/privacy-blackmoodstudio/home-page"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs md:text-sm text-neutral-500 hover:text-neutral-900 transition-colors duration-300"
          >
            Privacy & Cookie Policy
          </a>
        </div>
      </div>
    </footer>
  );
}
