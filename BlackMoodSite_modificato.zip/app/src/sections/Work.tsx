import { useEffect, useRef, useState } from 'react';
import { ExternalLink, Play, Disc3 } from 'lucide-react';

const tracks = [
  {
    id: '1',
    spotifyUrl: 'https://open.spotify.com/track/1ewFWzfcIjAx4G36WbDgX1',
    embedUrl:
      'https://open.spotify.com/embed/track/1ewFWzfcIjAx4G36WbDgX1?theme=0',
    title: 'Track 1',
    artist: 'Artista',
  },
  {
    id: '2',
    spotifyUrl: 'https://open.spotify.com/track/423yAZqzAQvHCidKPiBhkE',
    embedUrl:
      'https://open.spotify.com/embed/track/423yAZqzAQvHCidKPiBhkE?theme=0',
    title: 'Track 2',
    artist: 'Artista',
  },
  {
    id: '3',
    spotifyUrl: 'https://open.spotify.com/track/2j9His3b2NM30omK6OkzdK',
    embedUrl:
      'https://open.spotify.com/embed/track/2j9His3b2NM30omK6OkzdK?theme=0',
    title: 'Track 3',
    artist: 'Artista',
  },
];

interface TrackData {
  thumbnail_url?: string;
  title?: string;
  author_name?: string;
}

type WorkProps = {
  /** True when the user accepted "experience" cookies (third-party embeds like Spotify). */
  experienceConsent: boolean;
  /** Opens the cookie banner/settings. */
  onManageCookies: () => void;
};

export default function Work({ experienceConsent, onManageCookies }: WorkProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [trackData, setTrackData] = useState<Record<string, TrackData>>({});
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Load oEmbed data only after consent (avoids calling Spotify endpoints without permission).
  useEffect(() => {
    if (!isVisible || !experienceConsent) return;

    tracks.forEach(async (track) => {
      try {
        const response = await fetch(
          `https://open.spotify.com/oembed?url=${encodeURIComponent(
            track.spotifyUrl
          )}`
        );
        if (response.ok) {
          const data = await response.json();
          setTrackData((prev) => ({ ...prev, [track.id]: data }));
        }
      } catch (error) {
        console.error('Failed to load track data:', error);
      }
    });
  }, [isVisible, experienceConsent]);

  return (
    <section
      id="work"
      ref={sectionRef}
      className="relative min-h-screen overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <picture>
          <source
            media="(max-width: 900px)"
            srcSet="https://i.postimg.cc/NFmdMppp/Blackmood-91.jpg"
          />
          <img
            src="https://i.postimg.cc/QMhTqtGW/Blackmood-89.jpg"
            alt="Lavori"
            className="w-full h-full object-cover"
          />
        </picture>
        {/* Vignette */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(60% 40% at 50% 20%, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.6) 72%)',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-end lg:items-center lg:justify-end">
        {/* Panel */}
        <div
          className={`w-full lg:w-[min(33.333%,420px)] glass-panel flex items-start transition-all duration-1000 ${
            isVisible
              ? 'opacity-100 translate-y-0 lg:translate-x-0'
              : 'opacity-0 translate-y-10 lg:translate-x-20'
          }`}
        >
          <div className="p-5 md:p-6 lg:p-8 w-full">
            {/* Title */}
            <div
              className={`flex items-center gap-2.5 mb-5 md:mb-6 transition-all duration-700 delay-200 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-6'
              }`}
            >
              <Disc3 className="w-6 h-6 md:w-7 md:h-7 text-rose-400 animate-spin" style={{ animationDuration: '8s' }} />
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-medium text-white">
                Lavori
              </h2>
            </div>

            {/* Cookie notice (single consent managed by the global banner) */}
            {!experienceConsent && (
              <div
                className={`mb-4 p-3 rounded-lg bg-black/60 border border-white/10 backdrop-blur-sm transition-all duration-700 delay-300 ${
                  isVisible
                    ? 'opacity-100 translate-y-0'
                    : 'opacity-0 translate-y-6'
                }`}
              >
                <p className="text-xs text-white/70 mb-2">
                  Per ascoltare le tracce, abilita i contenuti esterni (Spotify) dal banner cookie.
                </p>
                <button
                  onClick={onManageCookies}
                  className="btn-shine px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700 transition-colors duration-300"
                >
                  Gestisci cookie
                </button>
              </div>
            )}

            {/* Tracks List */}
            <div className="space-y-3">
              {tracks.map((track, index) => (
                <div
                  key={track.id}
                  className={`group transition-all duration-500 ${
                    isVisible
                      ? 'opacity-100 translate-y-0'
                      : 'opacity-0 translate-y-6'
                  }`}
                  style={{ transitionDelay: `${400 + index * 100}ms` }}
                >
                  {experienceConsent ? (
                    // Spotify Embed
                    <div className="rounded-xl overflow-hidden border border-white/10 hover:border-rose-500/30 transition-all duration-300 hover-lift">
                      <iframe
                        src={track.embedUrl}
                        width="100%"
                        height="80"
                        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
                        loading="lazy"
                        className="bg-black"
                        title={`${trackData[track.id]?.title || track.title} - Spotify`}
                      />
                    </div>
                  ) : (
                    // Cover Placeholder
                    <a
                      href={track.spotifyUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 hover:border-rose-500/30 transition-all duration-300 hover-lift"
                    >
                      {/* Cover Image */}
                      <div className="w-14 h-14 md:w-16 md:h-16 rounded-lg overflow-hidden bg-gradient-to-br from-rose-500/20 to-black flex-shrink-0 relative">
                        {trackData[track.id]?.thumbnail_url ? (
                          <img
                            src={trackData[track.id].thumbnail_url}
                            alt={trackData[track.id]?.title || track.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Play className="w-6 h-6 text-white/40" />
                          </div>
                        )}
                        {/* Play overlay */}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                          <ExternalLink className="w-5 h-5 text-white" />
                        </div>
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm text-white font-medium truncate group-hover:text-rose-300 transition-colors duration-300">
                          {trackData[track.id]?.title || track.title}
                        </h3>
                        <p className="text-white/60 text-xs truncate">
                          {trackData[track.id]?.author_name || track.artist}
                        </p>
                        <p className="text-white/40 text-[10px] mt-0.5 flex items-center gap-1">
                          <svg
                            className="w-3 h-3"
                            viewBox="0 0 24 24"
                            fill="currentColor"
                          >
                            <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z" />
                          </svg>
                          Spotify
                        </p>
                      </div>
                    </a>
                  )}
                </div>
              ))}
            </div>

            {/* View All Link */}
            <div
              className={`mt-5 text-center transition-all duration-700 delay-600 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-6'
              }`}
            >
              <a
                href="https://open.spotify.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-white/60 hover:text-rose-400 text-xs font-medium transition-colors duration-300"
              >
                Vedi tutti i lavori
                <ExternalLink size={14} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
