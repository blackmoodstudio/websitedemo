import { useEffect, useRef, useState } from 'react';
import { Mic2, Sliders, Headphones, Music } from 'lucide-react';

const features = [
  {
    icon: Mic2,
    title: 'Live Room',
    description: 'Riprese e prove in ambiente ottimizzato',
  },
  {
    icon: Sliders,
    title: 'Regia',
    description: 'Produzione e overdub professionale',
  },
  {
    icon: Headphones,
    title: 'Mix & Master',
    description: 'Sala dedicata alla finalizzazione',
  },
  {
    icon: Music,
    title: 'Streaming Ready',
    description: 'Consegne pronte per le piattaforme',
  },
];

export default function About() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative min-h-screen overflow-hidden"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://i.postimg.cc/j55jTx30/22.jpg"
          alt="Lo Studio"
          className="w-full h-full object-cover"
        />
        {/* Vignette */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(60% 40% at 50% 20%, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.6) 72%)',
          }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-end lg:items-center lg:justify-end">
        {/* Panel */}
        <div
          className={`w-full lg:w-[min(33.333%,480px)] glass-panel flex items-center transition-all duration-1000 ${
            isVisible
              ? 'opacity-100 translate-y-0 lg:translate-x-0'
              : 'opacity-0 translate-y-10 lg:translate-x-20'
          }`}
        >
          <div className="p-5 md:p-6 lg:p-8 w-full">
            {/* Photo (visible on smartphone too) */}
            <div
              className={`lg:hidden mb-4 rounded-xl overflow-hidden border border-white/10 transition-all duration-700 delay-150 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-4'
              }`}
            >
              <img
                src="https://i.postimg.cc/j55jTx30/22.jpg"
                alt="Lo Studio"
                className="w-full h-44 object-cover"
                loading="lazy"
              />
            </div>

            {/* Title */}
            <h2
              className={`text-2xl md:text-3xl lg:text-4xl font-medium text-white mb-4 md:mb-5 transition-all duration-700 delay-200 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-6'
              }`}
            >
              Lo Studio
            </h2>

            {/* Description */}
            <div
              className={`space-y-3 text-white/90 text-sm md:text-base leading-relaxed transition-all duration-700 delay-300 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-6'
              }`}
            >
              <p>
                Progettato per lavorare con precisione e continuità, Black Mood
                Studio integra una live room per riprese e prove, una regia per
                produzione e overdub e una sala dedicata a mix e mastering.
              </p>
              <p className="hidden sm:block">
                Il trattamento acustico con pannelli Vicoustic assicura decisioni
                affidabili, mentre la connessione tra le sale consente sessioni
                multitraccia in tempo reale.
              </p>
              <p className="text-white/70">
                Produzione, registrazione, editing, mix e mastering con consegne
                pronte per lo streaming.
              </p>
            </div>

            {/* Features Grid */}
            <div
              className={`grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-3 mt-6 transition-all duration-700 delay-500 ${
                isVisible
                  ? 'opacity-100 translate-y-0'
                  : 'opacity-0 translate-y-6'
              }`}
            >
              {features.map((feature, index) => (
                <div
                  key={feature.title}
                  className="group p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 hover:border-rose-500/30 transition-all duration-300"
                  style={{ transitionDelay: `${500 + index * 100}ms` }}
                >
                  <feature.icon className="w-5 h-5 text-rose-400 mb-1.5 group-hover:scale-110 transition-transform duration-300" />
                  <h3 className="text-xs font-semibold text-white mb-0.5">
                    {feature.title}
                  </h3>
                  <p className="text-[10px] text-white/60 leading-tight">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
