import { useEffect, useState } from 'react';
import Header from './sections/Header';
import Hero from './sections/Hero';
import About from './sections/About';
import Services from './sections/Services';
import Rooms from './sections/Rooms';
import Work from './sections/Work';
import Contact from './sections/Contact';
import { Cookie, X } from 'lucide-react';

function App() {
  const [showCookieBanner, setShowCookieBanner] = useState(false);
  const [cookieConsent, setCookieConsent] = useState<{
    necessary: boolean;
    experience: boolean;
  } | null>(null);
  const [hasCheckedConsent, setHasCheckedConsent] = useState(false);

  useEffect(() => {
    // Check for existing consent
    const stored = localStorage.getItem('bms_consent_v1');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setCookieConsent(parsed);
        setShowCookieBanner(false);
      } catch {
        setShowCookieBanner(true);
      }
    } else {
      setShowCookieBanner(true);
    }
    setHasCheckedConsent(true);
  }, []);

  const handleAcceptAll = () => {
    const consent = { necessary: true, experience: true };
    localStorage.setItem('bms_consent_v1', JSON.stringify(consent));
    setCookieConsent(consent);
    setShowCookieBanner(false);
  };

  const handleReject = () => {
    const consent = { necessary: true, experience: false };
    localStorage.setItem('bms_consent_v1', JSON.stringify(consent));
    setCookieConsent(consent);
    setShowCookieBanner(false);
  };

  const openCookieSettings = () => setShowCookieBanner(true);

  const handleCloseBanner = () => {
    // If the user has already made a choice in the past, closing should just dismiss.
    // If it's the first time, treat close as a rejection for "experience" cookies.
    if (cookieConsent || !hasCheckedConsent) {
      setShowCookieBanner(false);
      return;
    }
    handleReject();
  };

  return (
    <div className="relative">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main>
        <Hero />
        <About />
        <Services />
        <Rooms />
        <Work
          experienceConsent={!!cookieConsent?.experience}
          onManageCookies={openCookieSettings}
        />
        <Contact />
      </main>

      {/* Cookie Banner */}
      {showCookieBanner && (
        <div className="fixed bottom-4 left-4 right-4 z-50 animate-fade-in-up">
          <div className="max-w-4xl mx-auto">
            <div className="glass-panel rounded-2xl p-4 md:p-5 shadow-2xl border border-white/15">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                <div className="flex items-start gap-3 flex-1">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/20 flex items-center justify-center flex-shrink-0">
                    <Cookie className="w-5 h-5 text-rose-400" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white mb-1">
                      Cookie & contenuti esterni
                    </h3>
                    <p className="text-sm text-white/70">
                      Usiamo strumenti necessari e, solo con consenso, contenuti
                      esterni (es. Spotify) e font.{" "}
                      <a
                        href="https://sites.google.com/view/privacy-blackmoodstudio/home-page"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-rose-400 hover:text-rose-300 underline"
                      >
                        Leggi la policy
                      </a>
                      .
                    </p>
                  </div>
                </div>
                <div className="flex gap-3 w-full md:w-auto">
                  <button
                    onClick={handleReject}
                    className="flex-1 md:flex-none px-5 py-2.5 rounded-xl bg-black/40 border border-white/20 text-white text-sm font-semibold hover:bg-black/60 transition-colors duration-300"
                  >
                    Rifiuta
                  </button>
                  <button
                    onClick={handleAcceptAll}
                    className="flex-1 md:flex-none px-5 py-2.5 rounded-xl bg-white text-black text-sm font-semibold hover:bg-white/90 transition-colors duration-300"
                  >
                    Accetta
                  </button>
                </div>
                <button
                  onClick={handleCloseBanner}
                  className="absolute top-2 right-2 md:static p-2 text-white/50 hover:text-white transition-colors"
                  aria-label="Chiudi"
                >
                  <X size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
